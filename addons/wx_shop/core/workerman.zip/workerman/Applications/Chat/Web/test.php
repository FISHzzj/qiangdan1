 <?php
  $redis = new Redis();
  $redis -> pconnect('127.0.0.1', 6379,1);
  
  $stock = 300000;
  // 待秒杀的商品编号
  $goodsId = 1000001;

  // 将商品库存依次放入队列中
  for ($i=0; $i<$stock; $i++) {
      $redis->lPush('stock_'.$goodsId,$i);
  }
  // echo 2;exit;