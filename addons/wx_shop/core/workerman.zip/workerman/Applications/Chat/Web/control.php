<?php
	require_once '../mysql-master/src/Connection.php';
	class control{
		/**
	     * 新建一个类的静态成员，用来保存数据库实例
	     */
	    public static $db = null;
	    public $redis = null;
	    public static $redisnames = 're_';
	    function __construct(){
	    	self::$db = new Workerman\MySQL\Connection('120.25.64.250', '3306', '5424_iiio', '5424_plww', '5424_iiio');
	    	$redis = new Redis();
		   	$redis -> pconnect('127.0.0.1', 6379,1);
		   	$this ->redis = $redis; 
	    }
	    //发包
		public function setsome(){
			$uniacid = 96;
			$roomid = 1;
			$money = 800;
			$bao = 10;
			$lei = 2;
			$mid = '4003';
			$endtime = 300;
			//获取设置
			// $getPaperGet 	= 	$this->getPaperGet($uniacid);
			// $getPaperSet 	= 	$this->getPaperSet($uniacid);
			// $getBeiShu 		= 	$this->getBeiShu($uniacid,$roomid);
			// $getRobotGet 	= 	$this->getRobotGet($uniacid,$roomid);
			// $getRobotSet 	= 	$this->getRobotSet($uniacid,$roomid);
			$getRoomSet 	= 	$this->getRoomSet($uniacid,$roomid);
			$getRoomSet 	= 	json_decode($getRoomSet,true);
			$getCommonSet 	= 	$this->getCommonSet($uniacid);
			$getCommonSet 	= 	json_decode($getCommonSet,true);

			if($getRoomSet['minbao'] > $bao){
				echo '红包包数不能小于'.$getRoomSet['minbao'].'个';
			}
			if($getRoomSet['maxbao'] < $bao){
				echo '红包包数不能大于'.$getRoomSet['maxbao'].'个';
			}
			if($getRoomSet['max'] < $money){
				echo '红包金额不能大于'.$getRoomSet['maxbao'].'元';
			}
			if($getRoomSet['min'] > $money){
				echo '红包金额不能小于'.$getRoomSet['minbao'].'元';
			}
			$usermoney = $this->getUserMoney($mid,$uniacid);

			if($usermoney['credit2'] < $money){
				echo '余额不足';
			}
			//扣钱
			$this->upcredit($uniacid,$mid,$money,'setred','发红包扣除'.$money);
			//应该发给上级的钱
			$agentmoney = round($money * $getCommonSet['rate']/100,2);
			//作为红包的钱
			$insermoney = $redmoney = $money - $agentmoney;
			
			//获取系统设置的机器人列表
			$getPaperGet = $this->getPaperGet($uniacid);
			//获取改房间的机器人
			$getRobotGet = $this->getRobotGet($uniacid,$roomid);
			//取机器人人数
			$num = count($getRobotGet);
			//在机器人中列表中取 机器人人数
			$robotlist = array_rand($getPaperGet,$num);
			//红包中随机抽取两个包
			$beishu = $this->getBeiShu($uniacid,$roomid,$bao);

			$redlist = array();
			foreach ($getRobotGet as $k => $v) {
				$rget = json_decode($v,true);
				$islei = $this->get_rand(array('1'=>$rget['zhonglei'],'2'=>100-$rget['zhonglei']));
				$rmoney = $this->getrandmoney($redmoney);
				if($islei == 1){
					$rmoney['money'] 	= substr($rmoney['money'], 0, -1) . $lei;
					$rmoney['money'] 	= number_format($rmoney['money'], 2, '.', '');
					$rmoney['lei'] 		= $lei;
					$rmoney['endtime']	= time() + $rget['time'];
				}
				$redmoney = $redmoney - $rmoney['money'];
				$redlist[] = $rmoney;
				$bao = $bao - 1;
			}
			//红包数组
			$repaparlist = $this->getredpapar($redmoney,$bao);

			//分销的上级
			$repaparlists = json_encode($repaparlist);
			$redlists = json_encode($redlist);
			$data = array(
				'uniacid'		=>	$uniacid,
				'openid' 		=> 	$usermoney['openid'],
				'mid'			=>  $usermoney['id'],
				'setmoney' 		=>  $money,
				'money'			=>	$insermoney,
				'roomid'		=>  $roomid,
				'status'		=>  0,
				'setstatus'		=>  0,
				'rate'			=>	$getCommonSet['rate'],
				'bao'			=> 	$bao,
				'lei'			=> 	$lei,
				'createtime'	=> 	time(),
				'endtime'		=>  time()+$endtime,
				'type'			=> 	1,
				'redlist'		=>	$redlists,
				'repaparlist'	=>	$repaparlists,
				'surplus_money'	=> 	$insermoney,
				'surplus_bao'	=>	$bao,
				'bei'			=>	$beishu['beishu'],
			);
			$insert_id = self::$db->insert('ims_wx_shop_red_paper_list')->cols($data)->query();
			$this->getmyagent($usermoney['agentid'],$agentlist,0,6);
			$agarr = array('plid'=>$insert_id,'uniacid'=>$uniacid,'createtime'=>time());
			foreach ($agentlist as $k => $v) {
				if($getCommonSet['level'.$v['i']]){
					$agarr['level'.$v['i']] = $v['i'];
					$agarr['openid'.$v['i']] = $v['openid'];
					$agarr['mid'.$v['i']] = $v['id'];
					$agarr['money'.$v['i']] = round($agentmoney*$getCommonSet['level'.$v['i']]/100,2);
				}
			}
			$insert_aid = self::$db->insert('ims_wx_shop_red_paper_agentlist')->cols($agarr)->query();
			$datas = array(
				'mid'			=> $data['mid'],
				'setmoney'		=> $data['setmoney'],
				'status'		=> $data['status'],
				'setstatus'		=> $data['setstatus'],
				'bao'			=> $data['bao'],
				'lei'			=> $data['lei'],
				'surplus_money'	=> $data['surplus_money'],
				'surplus_bao'	=> $data['bao'],
				'bei'			=> $data['bei'],
				'endtime'		=> $data['endtime'],
				'createtime'	=> $data['createtime'],
				'redlist'		=> $redlist,
				'repaparlist'	=> $repaparlist,
			);
			$this->setRedis('room_paper_'.$roomid,$insert_id,$datas);
			
			echo '生成红包成功';
		}
		//抢包
		public function getsome(){
			//红包id
			$rid = 15;
			$roomid = 1;
			$mid = '4003';
			$usersign = '2';
			$uniacid = 96;
			$time = time();
			if(empty($rid)){
				echo '没有该红包';
				exit;
			}
			if(empty($roomid)){
				echo '没有该房间';
				exit;
			}
			if(empty($uniacid)){
				echo '请传输正确的公众信息参数';
				exit;
			}
			$tablenames = $this->redisTablename('getRoomSet',$uniacid);
			$roomset = $this->getRedis($tablenames,$roomid);
			if(empty($roomset)){
				echo '没有该房间信息';
				exit;
			}
			$rpinfo = $this->getRedis('room_paper_'.$roomid,$rid);
			if(empty($rpinfo)){
				echo '没有该红包';
				exit;
			}
			// if($rpinfo['endtime'] < time()){
			// 	echo '红包已过期,不可再抢';
			// 	exit;
			// }
			$usermoney = $this->getUserMoney($mid,$uniacid);
			if(empty($usermoney) || $usermoney['usersign'] != $usersign){
				echo '没有该会员或验证信息不匹配';
				exit;
			}
			if($usermoney['credit2'] < $rpinfo['setmoney'] * $rpinfo['bei']){
				echo '您的金额不足';
				exit;
			}

			$tabj = 'room_jpaper_'.$roomid.'_'.$rid;
			$tabu = 'room_upaper_'.$roomid.'_'.$rid;
			// $this->redis->expire($tabj,10000);
			// $this->redis->expire($tabu,10000);
			// foreach ($rpinfo['redlist'] as $ke => $va) {
			// 	$this->redis->lPush($tabj,json_encode($va));
			// }
			// foreach ($rpinfo['repaparlist'] as $ke => $va) {
			// 	$this->redis->lPush($tabu,json_encode($va));
			// }
			//会员抢包总数
			$tabuc = $this->redis->llen($tabu);
			$tabjc = $this->redis->llen($tabj);
			// $bb = $this->redis->lRange($tabu,0,-1);
			if(0 < $tabuc + $tabjc){
				$getCommonSet 	= 	$this->getCommonSet($uniacid);
				$getCommonSet 	= 	json_decode($getCommonSet,true);
				if( 0 < $tabuc ){
					// $aa = $this->redis->lPop($tabu);
					$aa = 1;
					if($aa){
						// $aa = json_decode($aa,true);
						$aa = array('money'=>36.69,'wei'=>9);
						//给上级的钱的比例
						$getag = round($aa['money'] * $roomset['reper_rate']/100,2);
						$getmy = $aa['money'] - $getag;
						if(intval($aa['wei']) == intval($rpinfo['lei'])){//中雷扣除钱
							$mysetmoney = round($rpinfo['setmoney'] * $rpinfo['bei'],2);
						}
						if($getag > 0){//如果有上级
							
						}
					}
				}else if(0 < $tabjc){
					echo 3;exit;
				}else{
					echo '红包已被抢完';
					exit;
				}
			}else{
				echo '红包已被抢完';
				exit;
			}

			// // $this->redis->lTrim('room_paper_'.$roomid.'_'.$rid, 0, 1);
			// $bb = $this->redis->lRange($tabu,0,-1);
			// $aa = $this->redis->llen($tabu);
			// var_dump($rpinfo);
			// var_dump($bb);exit;
			


			var_dump($rpinfo);exit;
		}
		//存入redis hash表
		public function setRedis($tables='',$id=0,$arr=array()){

			$arr = json_encode($arr);
			$this->redis->hSet($tables,$id,$arr);
		}
		//存入redis hash表
		public function getRedis($tables='',$id=0){
			$arr = $this->redis->hGet($tables,$id);
			$arr = json_decode($arr,true);
			return $arr;
		}
		//增加扣除 余额分方法
		public function upcredit($uniacid = 0,$mid = 0,$money=0,$type='setred',$main=''){
			$usermoney = $this->getUserMoney($mid,$uniacid);
			$data['credit2'] = $usermoney['credit2'] - $money;
			if($data['credit2'] < 0){
				$data['credit2'] = 0;
			}
			$this->updateSql('ims_wx_shop_member',$data,array('openid'=> $usermoney['openid'],'uniacid'=>$uniacid));
			$ins_log = array(
					'uniacid'		=> $uniacid,
					'openid'		=> $usermoney['openid'],
					'mid'			=> $usermoney['id'],
					'title'			=> $main,
					'rechargetype'	=> $type,
					'status'		=> 1,
				);
			$insert_aid = self::$db->insert('ims_wx_shop_member_log')->cols($ins_log)->query();
		}
		public function updateSql($tables='',$data1=array(),$data2=array()){
			$data2str = ' 1';
			foreach ($data2 as $k=> $v) {
				$data2str .= ' AND '.$k.'=:'.$k;
			}
			$row_count = self::$db->update($tables)
			->cols($data1)
			->where($data2str)
			->bindValues($data2)
			->query();
		}
		//求中雷概率
		public function get_rand($proArr) {
		     $result = '';
		     //概率数组的总概率精度
		     $proSum = array_sum($proArr);
		     //概率数组循环
		     foreach ($proArr as $key => $proCur) {
		         $randNum = mt_rand(1, $proSum);
		         if ($randNum <= $proCur) {
		             $result = $key;
		             break;
		         } else {
		             $proSum -= $proCur;
		         }
		     }
		     unset ($proArr);
		     return $result;
		 }
		//生成红包金额数组
		public function getredpapar($redmoney=0,$bao){
			$i = 1;
			$setmoney = $redmoney * 100;
			while ( $i <= $bao) {
				if($i == $bao){
					$getmoney = $setmoney;
				}else{
					if($i == 1){
						$randmoney = $setmoney * 0.2;
					}else if($i == 2){
						$randmoney = $setmoney * 0.3;
					}else{
						$randmoney = $setmoney * 0.6;
					}
					$getmoney = rand(1,$randmoney);
					$setmoney = $setmoney - $getmoney;
				}
				$arr['money'] = number_format($getmoney/100, 2, '.', '');
				$arr['wei'] = substr($arr['money'], -1);
				$moneylist[] = $arr;
				$i++;
			}
			return $moneylist;
		}
		//随机生成的钱数
		public function getrandmoney($redmoney=0){
			$setmoney = $redmoney * 100;
			$randmoney = $setmoney * 0.2;
			$getmoney = rand(1,$randmoney);
			$arr['money'] = number_format($getmoney/100, 2, '.', '');
			$arr['wei'] = substr($arr['money'], -1);
			return $arr;
		}
		/**
	     	* 无限查找上级 
	     	* @param int $uniacid 
	     	* @param string $table 
	     	* @param array $member 
	     	* @param array $twowayset 
	     	* @return array $userinfo
	    */
	    public function getmyagent($id = 0,&$arr,$i = 0,$ceng = 5){
		    if($ceng == 0){
		        return false;
		    }
	      	$i++;
	      	if($i == $ceng){
	        	return false;
	      	}
	      	if(empty($id)){
	      		return false;
	      	}
	      	$meminfo = self::$db->select('id,agentid,openid,nickname')
				->from('ims_wx_shop_member')
				->where('id = :id')
				->bindValues(array('id' => $id))
				->row();
	      	$meminfo['i'] = $i;
	      	if($meminfo['id']){
	        	$arr[] = $meminfo;
	        	$this->getmyagent($meminfo['agentid'],$arr,$i,$ceng);
	      	}
	      	return $arr;//返回数组取值
	    }
		//获取会员余额
		public function getUserMoney($mid='',$uniacid){
			$usermoney = self::$db->select('id,agentid,openid,credit1,credit2,usersign')
				->from('ims_wx_shop_member')
				->where('uniacid = :uniacid AND id = :mid')
				->bindValues(array('uniacid' => $uniacid,'mid'=>$mid))
				->row();
			return $usermoney;
		}
		//获取红包的公共设置
		public function getCommonSet($uniacid=0){
			$tablenames = $this->redisTablename('getCommonSet',1);
			$list = $this ->redis->hGet($tablenames,$uniacid);
			if(empty($list)){
				$list = self::$db->select('id,rate,level1,level2,level3,level4,level5,reper_rate,reper_level1,reper_level2,reper_level3,reper_level4,reper_level5')
				->from('ims_wx_shop_red_paper_common')
				->where('uniacid = :uniacid')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid))
				->row();
				if(empty($list)){
					return false;
				}
				$this ->redis->hSet($tablenames,$uniacid,json_encode($list));
				$list = $this->redis->hGet($tablenames,$uniacid);
			}
			return $list;
		}
		//获取获取对应房间设置
		public function getRoomSet($uniacid=0,$roomid=0){
			$tablenames = $this->redisTablename('getRoomSet',$uniacid);
			$list = $this ->redis->hGet($tablenames,$roomid);
			if(empty($list)){
				$list = self::$db->select('id,name,maxbao,minbao,min,max,images')
				->from('ims_wx_shop_red_paper_room')
				->where('uniacid = :uniacid AND id = :roomid')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid,'roomid'=>$roomid))
				->row();
				if(empty($list)){
					return false;
				}
				$this ->redis->hSet($tablenames,$roomid,json_encode($list));
				$list = $this->redis->hGet($tablenames,$roomid);
			}
			return $list;
		}
		//获取获取对应包数的中雷倍数
		public function getBeiShu($uniacid=0,$roomid=0,$bao=0){
			$list = self::$db->select('id,bao,beishu')
			->from('ims_wx_shop_red_paper_room_beishu')
			->where('uniacid = :uniacid AND roomid = :roomid AND bao = :bao')
			->orderByASC(array('id'))
			->bindValues(array('uniacid' => $uniacid,'roomid'=>$roomid,'bao'=>$bao))
			->row();
			return $list;
		}
		//获取获取对应包数的抢机器人
		public function getRobotGet($uniacid=0,$roomid=0){
			$tablenames = $this->redisTablename('getRobotGet',$uniacid,$roomid);
			$list = $this ->redis->hGetAll($tablenames);
			if(empty($list)){
				$list = self::$db->select('id,time,zhonglei')
				->from('ims_wx_shop_red_paper_robot_get')
				->where('uniacid = :uniacid AND roomid = :roomid')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid,'roomid'=>$roomid))
				->query();
				$list = $this->getList($list,$tablenames);
			}
			return $list;
		}
		//获取获取对应包数的发包机器人
		public function getRobotSet($uniacid=0,$roomid=0){
			$tablenames = $this->redisTablename('getRobotSet',$uniacid,$roomid);
			$list = $this ->redis->hGetAll($tablenames);
			if(empty($list)){
				$list = self::$db->select('id,time,baoshu,leinum,lei,minmoney,maxmoney')
				->from('ims_wx_shop_red_paper_robot_set')
				->where('uniacid = :uniacid AND roomid = :roomid')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid,'roomid'=>$roomid))
				->query();
				$list = $this->getList($list,$tablenames);
			}
			return $list;
		}
		//获取该抢包机器人
		public function getPaperGet($uniacid=0){
			$tablenames = $this->redisTablename('getPaperGet',$uniacid);
			$list = $this ->redis->hGetAll($tablenames);
			if(empty($list)){
				$list = self::$db->select('id,nickname,avatar')
				->from('ims_wx_shop_red_paper_get')
				->where('uniacid = :uniacid ')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid))
				->query();
				$list = $this->getList($list,$tablenames);
			}
			return $list;
		}
		//获取抢发机器人
		public function getPaperSet($uniacid=0){
			$tablenames = $this->redisTablename('getPaperSet',$uniacid);
			$list = $this ->redis->hGetAll($tablenames);
			if(empty($list)){
				$list = self::$db->select('id,nickname,avatar')
				->from('ims_wx_shop_red_paper_set')
				->where('uniacid = :uniacid ')
				->orderByASC(array('id'))
				->bindValues(array('uniacid' => $uniacid))
				->query();
				$list = $this->getList($list,$tablenames);
			}
			return $list;
		}
		//把数据存入redis中
		public function getList($list = array(),$tablenames = ''){
			$plist = array();
			foreach ($list as $ke => $va) {
				$plist[$va['id']] = json_encode($va);
			}
			if($plist && $tablenames){
				$this ->redis->hMset($tablenames,$plist);
				$list = $this ->redis->hGetAll($tablenames);
			}
			return $list;
		}
		public function redisTablename($name = 'table',$uniacid = 1,$roomid = 0){
			$tablenames = '';
			if($roomid > 0){
				$tablenames = self::$redisnames.$name.'_'.$uniacid.'_'.$roomid;
			}else{
				$tablenames = self::$redisnames.$name.'_'.$uniacid;
			}
			return $tablenames;
		}
		public function ingset(){
			$roomid 	= 1;
			$uniacid 	= 96;
			$this->getRobotGet($uniacid,$roomid);
			$this->getRobotSet($uniacid,$roomid);
			// $list = self::$db->select('id,setstatus,createtime,endtime')
			// ->from('ims_wx_shop_red_paper_list')
			// ->where('roomid = :roomid')
			// ->orderByDESC(array('id'))
			// ->bindValues(array('roomid'=>$roomid))
			// ->row();
			// var_dump($list);
			// $str = '{"mid":4004,"roomid":1,"setmoney":200,"status":0,"setstatus":0,"redlist":[{"endtime":1559532492,"id":6,"z":5},{"endtime":1559532494,"id":4,"z":10}],"repaparlist":[{"num":1},{"num":2},{"num":3},{"num":4}],"bao":6,"lei":1,"surplus_money":182,"surplus_bao":6,"bei":1.5,"endtime":1559542489,"createtime":1559532489,"jiqi":2}';
			// // $this->redis->hSet('aa',2,json_encode($list));
			// // $bb = $this->redis->hGet('aa',2);
			// $bb = $this->redis->hSet('room_paper_1',353,$str);
			// $bb = $this->redis->hGet('room_paper_1',353);
			// var_dump($bb);exit;
		}
	}
	$aa = new control();
	$bb = $aa->ingset(); 