<?php	
	$redis = new Redis();
    $redis -> pconnect('127.0.0.1', 6379,1);
    $goodsId = 1000001;
	$aa = $_GET['uid'];
	// var_dump($aa);exit;
	$is = $_GET['i'];
	if($is>0){
		$i = $is;
	}else{
		$i = 0;
	}
	while($aa > 3 && $i <= 10000000){
		// echo 2;
		$i++;
		$rs = $redis->lPop('stock_'.$goodsId);
        $num = sprintf('%05s', $i);
        if (!$rs) {
            echo '售罄了！用户'.$num;
            echo '<br/>';
            // 输出最终抢购成功的用户数量
            echo '最终抢购人数：'.$d.' 人';
            echo '<br/>';
            echo '<br/>';
            break;
        } else {
            $d++;
            // 将抢购成功的用户存入队列
            // $redisUtil->setLeftList('users',$num);
            echo $rs.'恭喜您！用户'.$num;
        }
        echo '<br/>';
	}
	echo 3;