<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */
//declare(ticks=1);

/**
 * 聊天主逻辑
 * 主要是处理 onMessage onClose 
 */
use \GatewayWorker\Lib\Gateway;
// require_once __DIR__ . '/mysql-master/src/Connection.php';
class setother
{

    //进行http请求
    public function httpset($roomid=0,$uniacid=0,$redis=''){
        // echo 2;return;
        // $url = 'http://'.$_SERVER['SERVER_NAME'] . '/app/index.php?i=' . $uniacid . '&c=entry&m=wx_shop&do=mobile&r=util.task.robotSet&mid=4004aabb&roomid='.$roomid;
        $url = 'http://5424.iiio.top/app/index.php?i=' . $uniacid . '&c=entry&m=wx_shop&do=mobile&r=util.task.robotSet&mid=4004aabb&roomid='.$roomid;
        // var_dump($url);exit;
        $str = $this->httpget($url);
        
        $info = json_decode($str,true);
        // var_dump($info['result']['datas']);
        if(!empty($info['result']['datas'])){
            $results = $info['result']['datas'];
            $rlist = array();
            foreach ($results as $ke => $va) {
                // $rinfo = $redis->hGet('room_paper_'.$roomid,$va['id']);
                
                // $rinfo = json_decode($rinfo,true);
                // if($rinfo && $rinfo['setstatus'] == 0){
                    $rlist[]            =   $va;
                    // $rinfo['setstatus'] =   1;
                    // $rinfo              =   json_encode($rinfo);
                    // $redis->hSet('room_paper_'.$room_id,$va['id'],$rinfo);
                // }
            }
            $new_message = array(
                                'type'          =>  'setpar',
                                // 'client_id'     =>  $client_id,
                                            // 'client_name'   =>  htmlspecialchars($client_name), 
                                'time'          =>  date('Y-m-d H:i:s'),
                                'data'          =>  array(
                                                        'result'=>$rlist
                                                    )
                                );
            
            Gateway::sendToGroup($roomid, json_encode($new_message));
        }else{
            return;
        }
        // var_dump($info['result']['datas']);
    }
    public function httpgetlist($roomid=0,$uniacid=0,$redis=''){
        $url = 'http://5424.iiio.top/app/index.php?i=' . $uniacid . '&c=entry&m=wx_shop&do=mobile&r=util.task.robotGet&mid=4004aabb&roomid='.$roomid;
        // var_dump($url);exit;
        $str    = $this->httpget($url);
        $info   = json_decode($str,true);
        if(!empty($info['result']['datas'])){
            $results = $info['result']['datas'];
            $rlist = array();
            foreach ($results as $ke => $va) {
                if($va['type'] == 1){//如果是真人发包
                    $sayToUid = $va['touid'];
                    $isOnline = Gateway::isUidOnline($sayToUid);
                    if($isOnline){
                        $new_message = array(
                            'type'          =>  'getpar',
                            // 'client_name'   =>  htmlspecialchars($client_name), 
                            'time'          =>  date('Y-m-d H:i:s'),
                            'data'          =>  array(
                                'rid'       =>  intval($va['rid']),
                                'touid'     =>  intval($va['touid']),
                                'islei'     =>  intval($va['islei']),
                                'roomid'    =>  intval($va['roomid']),
                                'nickname'  =>  htmlspecialchars($va['nickname']),
                                                            
                            )
                        );
                        //发送红包信息
                        Gateway::sendToUid($sayToUid, json_encode($new_message));
                    }
                }
            }
            
        }else{
            return;
        }
    }
    public function httpget($url=''){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        curl_close($curl);
        return $data;
    } 
    //请确保项目文件有可写权限，不然打印不了日志。
    public function log_pa($nine = ''){
        $myfile = fopen(dirname(__FILE__)."/log.txt", "a+");
        if(is_array($nine)){
            fwrite($myfile, print_r($nine,true)); 
        }else{
            fwrite($myfile, $nine);  
        }        
        $txt =date('Y-m-d H:i:s',time());
        fwrite($myfile, '<br>'.$txt."\n");
        fclose($myfile);
    }
}

