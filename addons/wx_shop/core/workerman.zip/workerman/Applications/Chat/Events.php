<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */
//declare(ticks=1);

/**
 * 聊天主逻辑
 * 主要是处理 onMessage onClose 
 */
use \GatewayWorker\Lib\Gateway;
use \Workerman\Lib\Timer;
require_once __DIR__ . '/setother.php';
// require_once __DIR__ . '/mysql-master/src/Connection.php';
class Events
{
   /**
     * 新建一个类的静态成员，用来保存数据库实例
     */
    public static $db = null;
    public $redis = null;
    /**
     * 进程启动后初始化数据库连接
     */
    public static function onWorkerStart($worker)
    {

        // self::$db = new Workerman\MySQL\Connection('120.25.64.250', '3306', '5424_iiio', '5424_plww', '5424_iiio');
        global $redis;
        global $setother;
        $redis = new \Redis();
        $redis -> pconnect('127.0.0.1',6379,0);
        $setother = new setother();
        // $this->redis=$redis;
    }

   /**
    * 有消息时
    * @param int $client_id
    * @param mixed $message
    */
   public static function onMessage($client_id, $message)
   {
        // debug
        echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id session:".json_encode($_SESSION)." onMessage:".$message."\n";
        
        // 客户端传递的是json数据
        $message_data = json_decode($message, true);
        if(!$message_data)
        {
            return ;
        }
        
        // 根据类型执行不同的业务
        switch($message_data['type'])
        {
            // 客户端回应服务端的心跳
            case 'pong':
                return;
            // 客户端登录 message格式: {type:login, name:xx, room_id:1} ，添加到客户端，广播给所有客户端xx进入聊天室
            case 'login':
                // 判断是否有房间号
                if(!isset($message_data['room_id']))
                {
                    throw new \Exception("\$message_data['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']} \$message:$message");
                }
                
                // 把房间号昵称放到session中
                $room_id = $message_data['room_id'];
                $client_name = htmlspecialchars($message_data['client_name']);
                $_SESSION['room_id']        = $room_id;
                $_SESSION['client_name']    = $client_name;
                global $setother;
                global $redis;
                $twotype = '';
                if(!empty(intval($message_data['uniacid']))){
                    $uniacid = intval($message_data['uniacid']);
                }
                if(!empty(trim($message_data['twotype']))){
                    $twotype = trim($message_data['twotype']);
                }
                // 获取房间内所有用户列表 
                $clients_list = Gateway::getClientSessionsByGroup($room_id);
                foreach($clients_list as $tmp_client_id=>$item)
                {
                    $clients_list[$tmp_client_id] = $item['client_name'];
                }
                $clients_list[$client_id] = $client_name;
                // 转播给当前房间的所有客户端，xx进入聊天室 message {type:login, client_id:xx, name:xx} 
                Gateway::bindUid($client_id, $client_name);
                
                $new_message = array('type'=>$message_data['type'], 'client_id'=>$client_id,'client_name'=>htmlspecialchars($client_name), 'time'=>date('Y-m-d H:i:s'));
                Gateway::sendToGroup($room_id, json_encode($new_message));
                Gateway::joinGroup($client_id, $room_id);

                //定时任务的id
                if($twotype && $twotype == 'inother' && !empty($uniacid)){

                    $roomtable = 'roomset_room'.$room_id;
                    $roomtmdidset = $redis->Get($roomtable);
                    $roomtmdidset = json_decode($roomtmdidset,true);
                    $countroom 	  = Gateway::getClientIdCountByGroup($room_id);

                    if($countroom == 1 && $roomtmdidset['setbaotmd'] && $roomtmdidset['setstatus'] ){//定时任务如果这个房间只有一个人
                    	if(!empty($roomtmdidset['setbaotmd'])){
                    		Timer::del($roomtmdidset['setbaotmd']);	//清掉之前的定时任务
                    	}
                    	if(!empty($roomtmdidset['getbaotmd'])){
                    		Timer::del($roomtmdidset['getbaotmd']); //清掉之前的定时任务
                    	}
	                    $roomtmdidset['setstatus'] = '';
	                    $roomtmdidset['setbaotmd'] = '';
	                    $roomtmdidset['getbaotmd'] = '';
	                    $roomtmdidset['getstatus'] = '';
                    }

                    if(empty($roomtmdidset['setbaotmd']) && empty($roomtmdidset['setstatus'])){
                        $infos 			= json_encode(array('setstatus'=>1));
                        $roomtmdidset   = $redis->Set($roomtable,$infos);
                        $tableheader	= 're_';
                        $tableset		= $tableheader.'getRobotSet_'.$uniacid.'_'.$room_id;
                        $setlist    	= $redis->hGetAll($tableset);
                        $counts  		= count($setlist);
                        $infos   		= array();
                        
                        if($counts){
                        	$tmdid      			= Timer::add(2, array($setother, 'httpset'), array($room_id, $uniacid,$redis), true);
                        	$infos['setbaotmd'] 	= $tmdid;
                        	$infos['setstatus'] 	= 1;
                        }
                        
                        
                        $tableget		= $tableheader.'getRobotGet_'.$uniacid.'_'.$room_id;
                        $getlist    	= $redis->hGetAll($tableget);
                        $countg  		= count($getlist);
                        
                        if($countg > 0){
                        	$gtmdid     = Timer::add(2, array($setother, 'httpgetlist'), array($room_id, $uniacid,$redis), true);
                        	$infos['getbaotmd'] 	= $tmdid;
                        	$infos['getstatus'] 	= 1;
                        }
                        $infos['setstatus'] 	= 1;
                        $infos          		= json_encode($infos);
                        $roomtmdidset   		= $redis->Set($roomtable,$infos);
                    }      
                }
                // 给当前用户发送用户列表 
                $new_message['client_list'] = $clients_list;
                Gateway::sendToCurrentClient(json_encode($new_message));
                return;
                
            // 客户端发言 message: {type:say, to_client_id:xx, content:xx}
            case 'say':
                // 非法请求
                if(!isset($_SESSION['room_id']))
                {
                    throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                }
                $room_id = $_SESSION['room_id'];
                $client_name = $_SESSION['client_name'];
                // $list = self::$db->select('*')->from('ims_wx_shop_member')->where('id>3')->limit(2)->query();
                // 私聊
                if($message_data['to_client_id'] != 'all')
                {
                    $new_message = array(
                        'type'=>'say',
                        'from_client_id'=>$client_id, 
                        'from_client_name' =>$client_name,
                        'to_client_id'=>$message_data['to_client_id'],
                        'content'=>"<b>对你说: </b>".nl2br(htmlspecialchars($message_data['content'])),
                        'time'=>date('Y-m-d H:i:s'),
                    );
                    Gateway::sendToClient($message_data['to_client_id'], json_encode($new_message));
                    $new_message['content'] = "<b>你对".htmlspecialchars($message_data['to_client_name'])."说: </b>".nl2br(htmlspecialchars($message_data['content']));
                    return Gateway::sendToCurrentClient(json_encode($new_message));
                }
                
                $new_message = array(
                    'type'=>'say', 
                    'from_client_id'=>$client_id,
                    'from_client_name' =>$client_name,
                    'to_client_id'=>'all',
                    'content'=>nl2br(htmlspecialchars($message_data['content'])),
                    'time'=>date('Y-m-d H:i:s'),
                    'list'=>$list,
                );
                return Gateway::sendToGroup($room_id ,json_encode($new_message));
            case 'setred':
            	
                //发放红包
                // 非法请求
                if(!isset($_SESSION['room_id']))
                {
                    throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                }
                $room_id = $_SESSION['room_id'];
                $client_name = $_SESSION['client_name'];
                $rid = intval($message_data['rid']);
                if(empty($rid)){
                    return;
                }
                global $redis;
                $rinfo = $redis->hGet('room_paper_'.$room_id,$rid);
                if($rinfo){
                    $rinfo = json_decode($rinfo,true);
                    if($rinfo['setstatus'] == 0){
                        $rinfo['setstatus'] = 1;
                        $rinfo_set = $rinfo;//发给群成员的信息
                        $rinfo = json_encode($rinfo);
                        $redis->hSet('room_paper_'.$room_id,$rid,$rinfo);
                        $new_message = array(
                                            'type'          =>  $message_data['type'],
                                            'client_id'     =>  $client_id,
                                            // 'client_name'   =>  htmlspecialchars($client_name), 
                                            'time'          =>  date('Y-m-d H:i:s'),
                                            'data'          =>  array(
                                                                'id'        =>  $rid,
                                                                'bao'       =>  $rinfo_set['bao'],
                                                                'lei'       =>  $rinfo_set['lei'],
                                                                'money'     =>  $rinfo_set['setmoney'],
                                                                'nickname'  =>  htmlspecialchars($message_data['nickname']),
                                                                'avatar'    =>  htmlspecialchars($message_data['avatar'])
                                                            )
                                        );
                        //发送红包信息
                        Gateway::sendToGroup($room_id, json_encode($new_message));
                    }
                }
                return;
            case 'sendToSet':
                if(!isset($_SESSION['room_id']))
                {
                    throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                }
                $room_id = $_SESSION['room_id'];
                $client_name = $_SESSION['client_name'];
                $sayToUid    = intval($message_data['data']['touid']);
                if(empty($sayToUid)){
                    return;
                }
                $isOnline = Gateway::isUidOnline($sayToUid);
                if($isOnline){
                    $new_message = array(
                                            'type'          =>  $message_data['type'],
                                            'client_id'     =>  $client_id,
                                            // 'client_name'   =>  htmlspecialchars($client_name), 
                                            'time'          =>  date('Y-m-d H:i:s'),
                                            'data'          =>  array(
                                                                'rid'       =>  intval($message_data['data']['rid']),
                                                                'touid'     =>  intval($message_data['data']['touid']),
                                                                'islei'     =>  intval($message_data['data']['islei']),
                                                                'roomid'    =>  intval($message_data['data']['roomid']),
                                                                'nickname'  =>  htmlspecialchars($message_data['data']['nickname']),
                                                        
                                                            )
                                    );
                    //发送红包信息
                    Gateway::sendToUid($sayToUid, json_encode($new_message));
                }
                return;
            case 'other':
                if(!isset($_SESSION['room_id']))
                {
                    throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                }
                $room_id = $_SESSION['room_id'];
                $client_name = $_SESSION['client_name'];
                
                // 私聊
                if($message_data['to_client_id'] != 'all')
                {
                    $new_message = array(
                        'type'=>'say',
                        'from_client_id'=>$client_id, 
                        'from_client_name' =>$client_name,
                        'to_client_id'=>$message_data['to_client_id'],
                        'content'=>"<b>对你说: </b>".nl2br(htmlspecialchars($message_data['content'])),
                        'time'=>date('Y-m-d H:i:s'),
                    );
                    Gateway::sendToClient($message_data['to_client_id'], json_encode($new_message));
                    $new_message['content'] = "<b>你对".htmlspecialchars($message_data['to_client_name'])."说: </b>".nl2br(htmlspecialchars($message_data['content']));
                    return Gateway::sendToCurrentClient(json_encode($new_message));
                }
                
                $new_message = array(
                    'type'=>'say', 
                    'from_client_id'=>$client_id,
                    'from_client_name' =>$client_name,
                    'to_client_id'=>'all',
                    'content'=>nl2br(htmlspecialchars($message_data['content'])),
                    'time'=>date('Y-m-d H:i:s'),
                );
                return Gateway::sendToGroup($room_id ,json_encode($new_message));
        }
   }

   /**
    * 当客户端断开连接时
    * @param integer $client_id 客户端id
    */
   public static function onClose($client_id)
   {
       // debug
       echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id onClose:''\n";
       
       // 从房间的客户端列表中删除
       if(isset($_SESSION['room_id']))
       {
           $room_id = $_SESSION['room_id'];
           $countroom = Gateway::getClientIdCountByGroup($room_id);
           if($countroom == 0){
                global $redis;
                $roomtable      = 'roomset_room'.$room_id;
                $roomtmdidset   = $redis->Get($roomtable);
                $roomtmdidset   = json_decode($roomtmdidset,true);
                if($roomtmdidset['setstatus'] == 1 || $roomtmdidset['getstatus'] == 1){
                    // 删除定时器
                    Timer::del($roomtmdidset['setbaotmd']);
                    Timer::del($roomtmdidset['getbaotmd']);
                    $roomtmdidset['setstatus'] = '';
                    $roomtmdidset['setbaotmd'] = '';
                    $roomtmdidset['getbaotmd'] = '';
                    $roomtmdidset['getstatus'] = '';
                    $redis->Set($roomtable,json_encode($roomtmdidset));
                }
           }
           $new_message = array('type'=>'logout', 'from_client_id'=>$client_id, 'from_client_name'=>$_SESSION['client_name'], 'time'=>date('Y-m-d H:i:s'));
           Gateway::sendToGroup($room_id, json_encode($new_message));
       }
   }
  
}
